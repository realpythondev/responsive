# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('blog_mods', '0002_blogpost_featured_video'),
        ('blog_mods', '0001_initial'),
    ]

    operations = [
    ]
