
DEBUG = True

# Make these unique, and don't share it with anybody.
SECRET_KEY = "8xgzu#9k8-3ba%^gkoz)2cl&oo%4!)pm&41e2*&pc65y9&!&60"
NEVERCACHE_KEY = "+$fe+akjmf)+hw_2icsapprqvvul%&ul*#(pp3(lr&apa6=-jl"

DATABASES = {
    "default": {
        # Ends with "postgresql_psycopg2", "mysql", "sqlite3" or "oracle".
        "ENGINE": "django.db.backends.sqlite3",
        # DB name or path to database file if using sqlite3.
        "NAME": "dev.db",
        # Not used with sqlite3.
        "USER": "jon",
        # Not used with sqlite3.
        "PASSWORD": "KingOfFootballing.",
        # Set to empty string for localhost. Not used with sqlite3.
        "HOST": "",
        # Set to empty string for default. Not used with sqlite3.
        "PORT": "",
        }
    }

ALLOWED_HOSTS = ['178.62.48.63']
