daemon -n africafa -l log.txt ./runserver.sh
